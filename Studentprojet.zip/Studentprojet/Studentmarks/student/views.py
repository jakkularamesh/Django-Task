from django.shortcuts import render
from student.forms import StudentForm
from student.models import Student

# Create your views here.
def index_view(request):
    return render(request,'student/index.html')


def index_view(request):
     form=StudentForm()
     if request.method=='POST':
         form=StudentForm(request.POST)
         if form.is_valid():
             form.save(commit=True)
         return index_view(request)
     return render(request,'templates/addstudent.html',{'form':form})


def list_student(request):
     student_list=Student.objects.all()
     return render(request,'templates/studentlist.html',{'student_list':student_list})

