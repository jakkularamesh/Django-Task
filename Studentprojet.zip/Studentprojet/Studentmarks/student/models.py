from django.db import models
import uuid
# Create your models here.
class Student(models.Model):
    name=models.CharField(max_length=30)
    roll_number=models.IntegerField()
    date_of_birth=models.DateField()

 #def __unicode__(self):
  #   return self.roll_number

